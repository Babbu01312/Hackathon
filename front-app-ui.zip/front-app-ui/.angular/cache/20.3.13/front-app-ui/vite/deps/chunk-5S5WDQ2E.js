// node_modules/@primeuix/utils/dist/classnames/index.mjs
function f(...e) {
  if (e) {
    let t2 = [];
    for (let i3 = 0; i3 < e.length; i3++) {
      let n2 = e[i3];
      if (!n2) continue;
      let s4 = typeof n2;
      if (s4 === "string" || s4 === "number") t2.push(n2);
      else if (s4 === "object") {
        let c4 = Array.isArray(n2) ? [f(...n2)] : Object.entries(n2).map(([r, o]) => o ? r : void 0);
        t2 = c4.length ? t2.concat(c4.filter((r) => !!r)) : t2;
      }
    }
    return t2.join(" ").trim();
  }
}

// node_modules/@primeuix/utils/dist/dom/index.mjs
function R(t2, e) {
  return t2 ? t2.classList ? t2.classList.contains(e) : new RegExp("(^| )" + e + "( |$)", "gi").test(t2.className) : false;
}
function W(t2, e) {
  if (t2 && e) {
    let o = (n2) => {
      R(t2, n2) || (t2.classList ? t2.classList.add(n2) : t2.className += " " + n2);
    };
    [e].flat().filter(Boolean).forEach((n2) => n2.split(" ").forEach(o));
  }
}
function P(t2, e) {
  if (t2 && e) {
    let o = (n2) => {
      t2.classList ? t2.classList.remove(n2) : t2.className = t2.className.replace(new RegExp("(^|\\b)" + n2.split(" ").join("|") + "(\\b|$)", "gi"), " ");
    };
    [e].flat().filter(Boolean).forEach((n2) => n2.split(" ").forEach(o));
  }
}
function x(t2) {
  for (let e of document == null ? void 0 : document.styleSheets) try {
    for (let o of e == null ? void 0 : e.cssRules) for (let n2 of o == null ? void 0 : o.style) if (t2.test(n2)) return { name: n2, value: o.style.getPropertyValue(n2).trim() };
  } catch (o) {
  }
  return null;
}
function E(t2) {
  return t2 ? Math.abs(t2.scrollLeft) : 0;
}
function v(t2, e) {
  if (t2 instanceof HTMLElement) {
    let o = t2.offsetWidth;
    if (e) {
      let n2 = getComputedStyle(t2);
      o += parseFloat(n2.marginLeft) + parseFloat(n2.marginRight);
    }
    return o;
  }
  return 0;
}
function c(t2) {
  return typeof Element != "undefined" ? t2 instanceof Element : t2 !== null && typeof t2 == "object" && t2.nodeType === 1 && typeof t2.nodeName == "string";
}
function A(t2, e = {}) {
  if (c(t2)) {
    let o = (n2, r) => {
      var l3, d2;
      let i3 = (l3 = t2 == null ? void 0 : t2.$attrs) != null && l3[n2] ? [(d2 = t2 == null ? void 0 : t2.$attrs) == null ? void 0 : d2[n2]] : [];
      return [r].flat().reduce((s4, a2) => {
        if (a2 != null) {
          let u2 = typeof a2;
          if (u2 === "string" || u2 === "number") s4.push(a2);
          else if (u2 === "object") {
            let p3 = Array.isArray(a2) ? o(n2, a2) : Object.entries(a2).map(([f2, g3]) => n2 === "style" && (g3 || g3 === 0) ? `${f2.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}:${g3}` : g3 ? f2 : void 0);
            s4 = p3.length ? s4.concat(p3.filter((f2) => !!f2)) : s4;
          }
        }
        return s4;
      }, i3);
    };
    Object.entries(e).forEach(([n2, r]) => {
      if (r != null) {
        let i3 = n2.match(/^on(.+)/);
        i3 ? t2.addEventListener(i3[1].toLowerCase(), r) : n2 === "p-bind" || n2 === "pBind" ? A(t2, r) : (r = n2 === "class" ? [...new Set(o("class", r))].join(" ").trim() : n2 === "style" ? o("style", r).join(";").trim() : r, (t2.$attrs = t2.$attrs || {}) && (t2.$attrs[n2] = r), t2.setAttribute(n2, r));
      }
    });
  }
}
function U(t2, e = {}, ...o) {
  if (t2) {
    let n2 = document.createElement(t2);
    return A(n2, e), n2.append(...o), n2;
  }
}
function z(t2, e) {
  return c(t2) ? t2.matches(e) ? t2 : t2.querySelector(e) : null;
}
function Tt(t2) {
  if (t2) {
    let e = t2.offsetHeight, o = getComputedStyle(t2);
    return e -= parseFloat(o.paddingTop) + parseFloat(o.paddingBottom) + parseFloat(o.borderTopWidth) + parseFloat(o.borderBottomWidth), e;
  }
  return 0;
}
function K(t2) {
  if (t2) {
    let e = t2.getBoundingClientRect();
    return { top: e.top + (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0), left: e.left + (window.pageXOffset || E(document.documentElement) || E(document.body) || 0) };
  }
  return { top: "auto", left: "auto" };
}
function C(t2, e) {
  if (t2) {
    let o = t2.offsetHeight;
    if (e) {
      let n2 = getComputedStyle(t2);
      o += parseFloat(n2.marginTop) + parseFloat(n2.marginBottom);
    }
    return o;
  }
  return 0;
}
function Rt(t2) {
  if (t2) {
    let e = t2.offsetWidth, o = getComputedStyle(t2);
    return e -= parseFloat(o.paddingLeft) + parseFloat(o.paddingRight) + parseFloat(o.borderLeftWidth) + parseFloat(o.borderRightWidth), e;
  }
  return 0;
}
function Zt(t2) {
  var e;
  t2 && ("remove" in Element.prototype ? t2.remove() : (e = t2.parentNode) == null || e.removeChild(t2));
}
function _t(t2, e = "", o) {
  c(t2) && o !== null && o !== void 0 && t2.setAttribute(e, o);
}

// node_modules/@primeuix/utils/dist/object/index.mjs
function l(e) {
  return e == null || e === "" || Array.isArray(e) && e.length === 0 || !(e instanceof Date) && typeof e == "object" && Object.keys(e).length === 0;
}
function b(e, t2, n2 = /* @__PURE__ */ new WeakSet()) {
  if (e === t2) return true;
  if (!e || !t2 || typeof e != "object" || typeof t2 != "object" || n2.has(e) || n2.has(t2)) return false;
  n2.add(e).add(t2);
  let o = Array.isArray(e), r = Array.isArray(t2), u2, f2, T;
  if (o && r) {
    if (f2 = e.length, f2 != t2.length) return false;
    for (u2 = f2; u2-- !== 0; ) if (!b(e[u2], t2[u2], n2)) return false;
    return true;
  }
  if (o != r) return false;
  let S = e instanceof Date, A2 = t2 instanceof Date;
  if (S != A2) return false;
  if (S && A2) return e.getTime() == t2.getTime();
  let I = e instanceof RegExp, L = t2 instanceof RegExp;
  if (I != L) return false;
  if (I && L) return e.toString() == t2.toString();
  let R2 = Object.keys(e);
  if (f2 = R2.length, f2 !== Object.keys(t2).length) return false;
  for (u2 = f2; u2-- !== 0; ) if (!Object.prototype.hasOwnProperty.call(t2, R2[u2])) return false;
  for (u2 = f2; u2-- !== 0; ) if (T = R2[u2], !b(e[T], t2[T], n2)) return false;
  return true;
}
function y(e, t2) {
  return b(e, t2);
}
function c2(e) {
  return typeof e == "function" && "call" in e && "apply" in e;
}
function s(e) {
  return !l(e);
}
function p(e, t2) {
  if (!e || !t2) return null;
  try {
    let n2 = e[t2];
    if (s(n2)) return n2;
  } catch (n2) {
  }
  if (Object.keys(e).length) {
    if (c2(t2)) return t2(e);
    if (t2.indexOf(".") === -1) return e[t2];
    {
      let n2 = t2.split("."), o = e;
      for (let r = 0, u2 = n2.length; r < u2; ++r) {
        if (o == null) return null;
        o = o[n2[r]];
      }
      return o;
    }
  }
  return null;
}
function k(e, t2, n2) {
  return n2 ? p(e, n2) === p(t2, n2) : y(e, t2);
}
function i(e, t2 = true) {
  return e instanceof Object && e.constructor === Object && (t2 || Object.keys(e).length !== 0);
}
function m(e, ...t2) {
  return c2(e) ? e(...t2) : e;
}
function a(e, t2 = true) {
  return typeof e == "string" && (t2 || e !== "");
}
function g(e) {
  return a(e) ? e.replace(/(-|_)/g, "").toLowerCase() : e;
}
function F(e, t2 = "", n2 = {}) {
  let o = g(t2).split("."), r = o.shift();
  if (r) {
    if (i(e)) {
      let u2 = Object.keys(e).find((f2) => g(f2) === r) || "";
      return F(m(e[u2], n2), o.join("."), n2);
    }
    return;
  }
  return m(e, n2);
}
function C2(e, t2 = true) {
  return Array.isArray(e) && (t2 || e.length !== 0);
}
function z2(e) {
  return s(e) && !isNaN(e);
}
function G(e, t2) {
  if (t2) {
    let n2 = t2.test(e);
    return t2.lastIndex = 0, n2;
  }
  return false;
}
function Y(e) {
  return e && e.replace(/\/\*(?:(?!\*\/)[\s\S])*\*\/|[\r\n\t]+/g, "").replace(/ {2,}/g, " ").replace(/ ([{:}]) /g, "$1").replace(/([;,]) /g, "$1").replace(/ !/g, "!").replace(/: /g, ":").trim();
}
function X(e) {
  if (e && /[\xC0-\xFF\u0100-\u017E]/.test(e)) {
    let n2 = { A: /[\xC0-\xC5\u0100\u0102\u0104]/g, AE: /[\xC6]/g, C: /[\xC7\u0106\u0108\u010A\u010C]/g, D: /[\xD0\u010E\u0110]/g, E: /[\xC8-\xCB\u0112\u0114\u0116\u0118\u011A]/g, G: /[\u011C\u011E\u0120\u0122]/g, H: /[\u0124\u0126]/g, I: /[\xCC-\xCF\u0128\u012A\u012C\u012E\u0130]/g, IJ: /[\u0132]/g, J: /[\u0134]/g, K: /[\u0136]/g, L: /[\u0139\u013B\u013D\u013F\u0141]/g, N: /[\xD1\u0143\u0145\u0147\u014A]/g, O: /[\xD2-\xD6\xD8\u014C\u014E\u0150]/g, OE: /[\u0152]/g, R: /[\u0154\u0156\u0158]/g, S: /[\u015A\u015C\u015E\u0160]/g, T: /[\u0162\u0164\u0166]/g, U: /[\xD9-\xDC\u0168\u016A\u016C\u016E\u0170\u0172]/g, W: /[\u0174]/g, Y: /[\xDD\u0176\u0178]/g, Z: /[\u0179\u017B\u017D]/g, a: /[\xE0-\xE5\u0101\u0103\u0105]/g, ae: /[\xE6]/g, c: /[\xE7\u0107\u0109\u010B\u010D]/g, d: /[\u010F\u0111]/g, e: /[\xE8-\xEB\u0113\u0115\u0117\u0119\u011B]/g, g: /[\u011D\u011F\u0121\u0123]/g, i: /[\xEC-\xEF\u0129\u012B\u012D\u012F\u0131]/g, ij: /[\u0133]/g, j: /[\u0135]/g, k: /[\u0137,\u0138]/g, l: /[\u013A\u013C\u013E\u0140\u0142]/g, n: /[\xF1\u0144\u0146\u0148\u014B]/g, p: /[\xFE]/g, o: /[\xF2-\xF6\xF8\u014D\u014F\u0151]/g, oe: /[\u0153]/g, r: /[\u0155\u0157\u0159]/g, s: /[\u015B\u015D\u015F\u0161]/g, t: /[\u0163\u0165\u0167]/g, u: /[\xF9-\xFC\u0169\u016B\u016D\u016F\u0171\u0173]/g, w: /[\u0175]/g, y: /[\xFD\xFF\u0177]/g, z: /[\u017A\u017C\u017E]/g };
    for (let o in n2) e = e.replace(n2[o], o);
  }
  return e;
}
function re(e) {
  return a(e) ? e.replace(/(_)/g, "-").replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase() : e;
}

// node_modules/@primeuix/utils/dist/eventbus/index.mjs
function s2() {
  let r = /* @__PURE__ */ new Map();
  return { on(e, t2) {
    let n2 = r.get(e);
    return n2 ? n2.push(t2) : n2 = [t2], r.set(e, n2), this;
  }, off(e, t2) {
    let n2 = r.get(e);
    return n2 && n2.splice(n2.indexOf(t2) >>> 0, 1), this;
  }, emit(e, t2) {
    let n2 = r.get(e);
    n2 && n2.forEach((i3) => {
      i3(t2);
    });
  }, clear() {
    r.clear();
  } };
}

// node_modules/@primeuix/utils/dist/mergeprops/index.mjs
var p2 = Object.defineProperty;
var i2 = Object.getOwnPropertySymbols;
var x2 = Object.prototype.hasOwnProperty;
var c3 = Object.prototype.propertyIsEnumerable;
var d = (t2, e, a2) => e in t2 ? p2(t2, e, { enumerable: true, configurable: true, writable: true, value: a2 }) : t2[e] = a2;
var n = (t2, e) => {
  for (var a2 in e || (e = {})) x2.call(e, a2) && d(t2, a2, e[a2]);
  if (i2) for (var a2 of i2(e)) c3.call(e, a2) && d(t2, a2, e[a2]);
  return t2;
};
function u(...t2) {
  if (t2) {
    let e = [];
    for (let a2 = 0; a2 < t2.length; a2++) {
      let o = t2[a2];
      if (!o) continue;
      let r = typeof o;
      if (r === "string" || r === "number") e.push(o);
      else if (r === "object") {
        let s4 = Array.isArray(o) ? [u(...o)] : Object.entries(o).map(([f2, m2]) => m2 ? f2 : void 0);
        e = s4.length ? e.concat(s4.filter((f2) => !!f2)) : e;
      }
    }
    return e.join(" ").trim();
  }
}
function l2(t2) {
  return typeof t2 == "function" && "call" in t2 && "apply" in t2;
}
function w(...t2) {
  return t2 == null ? void 0 : t2.reduce((e, a2 = {}) => {
    for (let o in a2) {
      let r = a2[o];
      if (o === "style") e.style = n(n({}, e.style), a2.style);
      else if (o === "class" || o === "className") e[o] = u(e[o], a2[o]);
      else if (l2(r)) {
        let s4 = e[o];
        e[o] = s4 ? (...f2) => {
          s4(...f2), r(...f2);
        } : r;
      } else e[o] = r;
    }
    return e;
  }, {});
}

// node_modules/@primeuix/utils/dist/uuid/index.mjs
var t = {};
function s3(n2 = "pui_id_") {
  return Object.hasOwn(t, n2) || (t[n2] = 0), t[n2]++, `${n2}${t[n2]}`;
}

// node_modules/@primeuix/utils/dist/zindex/index.mjs
function g2() {
  let r = [], i3 = (e, n2, t2 = 999) => {
    let s4 = u2(e, n2, t2), o = s4.value + (s4.key === e ? 0 : t2) + 1;
    return r.push({ key: e, value: o }), o;
  }, d2 = (e) => {
    r = r.filter((n2) => n2.value !== e);
  }, a2 = (e, n2) => u2(e, n2).value, u2 = (e, n2, t2 = 0) => [...r].reverse().find((s4) => n2 ? true : s4.key === e) || { key: e, value: t2 }, l3 = (e) => e && parseInt(e.style.zIndex, 10) || 0;
  return { get: l3, set: (e, n2, t2) => {
    n2 && (n2.style.zIndex = String(i3(e, true, t2)));
  }, clear: (e) => {
    e && (d2(l3(e)), e.style.zIndex = "");
  }, getCurrent: (e) => a2(e, true) };
}
var x3 = g2();

export {
  f,
  R,
  W,
  P,
  x,
  v,
  A,
  U,
  z,
  Tt,
  K,
  C,
  Rt,
  Zt,
  _t,
  s2 as s,
  w,
  l,
  c2 as c,
  s as s2,
  p,
  k,
  i,
  m,
  a,
  g,
  F,
  C2,
  z2,
  G,
  Y,
  X,
  re,
  s3
};
//# sourceMappingURL=chunk-5S5WDQ2E.js.map
