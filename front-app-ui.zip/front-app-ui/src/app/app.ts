import { CommonModule } from '@angular/common';
import { Component, signal } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { ChatPanel } from './chat-panel/chat-panel';

@Component({
  selector: 'app-root',
  imports: [CommonModule, ButtonModule, ChatPanel],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  // signal to control panel open/close
  chatOpen = true;

  toggleChat() {
    this.chatOpen = !this.chatOpen;
  }

  protected readonly title = signal('front-app-ui');
}
