import { CommonModule } from '@angular/common';
import { AfterViewChecked, ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';
import { Chat, ChatMessage } from '../services/chat';

@Component({
  selector: 'app-chat-panel',
  imports: [CommonModule, FormsModule, InputTextModule, ButtonModule, CardModule, ],
  templateUrl: './chat-panel.html',
  styleUrl: './chat-panel.scss',
})
export class ChatPanel implements AfterViewChecked {
  message = '';
  messages: ChatMessage[] = [];
  loading = false;

   @ViewChild('scrollContainer') scrollContainer!: ElementRef<HTMLDivElement>;

   constructor(private chatService: Chat, private cd: ChangeDetectorRef) {
    // optional: seed message
    this.messages = [
      { from: 'bot', text: 'Hi! Ask me anything.' }
    ];
  }

  async send() {
    const text = this.message?.trim();
    if (!text) return;
    // push user message
    this.messages.push({ from: 'user', text });
    this.message = '';
    this.loading = true;
    const resp = await this.chatService.ask(text).subscribe({
      next:((res)=>{
        debugger
        if(res.status === 200){
          this.messages.push({ from: 'bot', text: res.output });
        }  
    this.cd.detectChanges();
    this.loading = false;
    this.scrollToBottom();
      })
    });
    
  }

  ngAfterViewChecked(): void {
    this.scrollToBottom();
  }

  private scrollToBottom() {
    try {
      const el = this.scrollContainer?.nativeElement;
      if (el) el.scrollTop = el.scrollHeight;
    } catch {}
  }
}
