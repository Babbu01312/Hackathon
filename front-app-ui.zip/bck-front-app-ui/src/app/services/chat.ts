import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

export interface ChatMessage {
  from: 'user' | 'bot';
  text: string;
}

@Injectable({
  providedIn: 'root',
})
export class Chat {
  private endpoint = 'http://127.0.0.1:8000/ai/chatbot/';
  constructor(private http: HttpClient) { }

  ask(query: string): Observable<{'status': number, 'output': any}> {
    return this.http.get<{'status': number, 'output': any}>(this.endpoint+`?query=${query}` ).pipe(
      map(res => {
        return res}) // assuming your API returns { answer: "..." }
    );
  }
  // Mocked response — replace with HTTP/LLM call when ready
  // async ask(question: string): Promise<string> {
  //   // simulate network latency
  //   await this.delay(700);

  //   // minimal mock logic
  //   const q = question.toLowerCase();
  //   if (q.includes('angular')) {
  //     return 'Angular is a platform for building mobile and desktop web applications.';
  //   }
  //   if (q.includes('hello') || q.includes('hi')) {
  //     return 'Hello! How can I help you today?';
  //   }
  //   return `I heard: "${question}". (This is a mocked response — wire to your API to return real answers.)`;
  // }

  // private delay(ms: number) {
  //   return new Promise(res => setTimeout(res, ms));
  // }
}
