from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from src.utils.evaluation import evaluator_agent
from src.utils.chatbot import chatbot
app = FastAPI()
from dotenv import load_dotenv

load_dotenv()

# List of allowed origins (Angular dev server)
origins = [
    "http://localhost:4200",  # Angular default dev server
    "http://127.0.0.1:4200"
]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,            # Allowed origins
    allow_credentials=True,
    allow_methods=["*"],              # Allow all HTTP methods
    allow_headers=["*"],              # Allow all headers
)

@app.get("/")
def read_root():
    return {"message": "Hello, Team 007!"}

@app.get("/ai/chatbot/")
def chat_bot(query):
    try:
        print("****************")
        response = chatbot(query=query).chat()
        return {'status': 200, 'output': response}
    except Exception as e:
        print(e)
        return {'status': 500, 'output': 'Error'}

@app.get('/ai/evalution/')
def evaluate(input, response):
    try:
        evaluation = evaluator_agent().evaluate(input=input, response=response)
        return {'status': 200, 'output': evaluation}
    except Exception as e:
        print(e)
        return {'status': 500, 'output': 'Error'}

