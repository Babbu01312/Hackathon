import pandas as pd
import httpx
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from src.utils.process_document import document_loader


class chatbot:
    def __init__(self, query):
        self.query = query
        self.llm=ChatOpenAI(
            base_url="https://genailab.tcs.in",
            model="azure/genailab-maas-gpt-35-turbo",
            api_key="sk-9bSwBSKqIHJiks5dkiDUTQ",
            http_client=httpx.Client(verify=False)      
            )
    def chat(self):
        print("You are inside chat")
        context = document_loader().extract_content()

        prompt = f"""You are a ChatBot. Your Task is the answer query: {self.query}. Based of the conext {context}"""

        response = self.llm.invoke(prompt)
        return response.content
